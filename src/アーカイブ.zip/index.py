import boto3
import json
import logging
import os

from bs4 import BeautifulSoup
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from operator import itemgetter

HOOK_URL = os.environ['hookUrl']
SLACK_CHANNEL = os.environ['slackChannel']

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    logger.info("Event: " + str(event))
    
    url = "https://coinmarketcap.com/"
    html = urlopen(url)
    soup = BeautifulSoup(html, "html.parser")
    span = soup.find_all('tr', class_="cmc-table-row")

    coins = []
    iost = ()

    for tag in span:
        try:
            td = tag.findAll('td')
            rank = td[0].find('div').string
            coinName = td[1].find('a').get("title")
            marketCap = td[2].find('div').string
            price = td[3].find('a').string
            volatility = float(td[6].find('div').string.split('%')[0])
            coinInfo = (
                    rank,
                    coinName,
                    marketCap,
                    price,
                    volatility
            )

            if coinName == 'IOST':
                iost = coinInfo

            coins.append(coinInfo)
        
        except:
            pass

    coins = sorted(coins, key=itemgetter(4))

    slack_message = {
        'channel': SLACK_CHANNEL,
        'Today\'s IOST Info': {
              rank: iost[0],
              coinName: iost[1],
              price: iost[3] ,
              volatility: iost[4]
          },
        'Today\'s Best 3': {
              1: {
                  rank: coins[0][0],
                  coinName: coins[0][1],
                  price: coins[0][3],
                  volatility: coins[0][4]
              },
              2: {
                  rank: coins[1][0],
                  coinName: coins[1][1],
                  price: coins[1][3],
                  volatility: coins[1][4]
              },
              3: {
                  rank: coins[2][0],
                  coinName: coins[2][1],
                  price: coins[2][3],
                  volatility: coins[2][4]
              }
        },
        'Today\'s Worst 3': {
              1: {
                  rank: coins[-1][0],
                  coinName: coins[-1][1],
                  price: coins[-1][3],
                  volatility: coins[-1][4]
              },
              2: {
                  rank: coins[-2][0],
                  coinName: coins[-2][1],
                  price: coins[-2][3],
                  volatility: coins[-2][4]
            },
              3: {
                  rank: coins[-3][0],
                  coinName: coins[-3][1],
                  price: coins[-3][3],
                  volatility: coins[-3][4]
              }
        }
    }

    req = Request(HOOK_URL, json.dumps(slack_message).encode('utf-8'))

    try:
        response = urlopen(req)
        response.read()
        logger.info("Message posted to %s", slack_message['channel'])
    except HTTPError as e:
        logger.error("Request failed: %d %s", e.code, e.reason)
    except URLError as e:
        logger.error("Server connection failed: %s", e.reason)
